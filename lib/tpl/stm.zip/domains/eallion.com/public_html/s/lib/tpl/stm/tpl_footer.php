<?php
/**
 * Template footer, included in the main and detail files
 */

// must be run from within DokuWiki
if (!defined('DOKU_INC')) die();
?>

<!-- ********** FOOTER ********** -->
<footer class="footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?>. Powered by <a href="https://www.dokuwiki.org" target="_blank">Dokuwiki</a> / Theme by <a href="https://github.com/Fraina/STM-Dokuwiki-Template" target="_blank">Fraina</a> / Designed by <a href="http://eallion.com" target="_blank">eallion</a> Ver3.1.2 / <a href="http://s.eallion.com/old" target="_blank">Old</a> | MyIP：<a href="https://www.baidu.com/s?wd=<?php $ip = $_SERVER["REMOTE_ADDR"]; echo $ip;?>" target="_blank"><?php $ip = $_SERVER["REMOTE_ADDR"]; echo $ip;?></a> / <a href="https://github.com/racaljk/hosts" target="_blank">hosts</a> / <a href="http://my.yizhihongxing.com/aff.php?aff=2106" target="_blank">Shadowsocks</a><br />
        </p>
    </div>
</footer>